import Head from 'next/head';
import { useState } from 'react';
import ChatWidget from '../components/ChatWidget';

const C = {
  navy:      '#0A1628',
  navyDark:  '#060E1A',
  navyCard:  '#0F1E35',
  navyLight: '#1A2E4A',
  green:     '#54F228',
  gold:      '#F5A623',
  purple:    '#6A4FE0',
  blue:      '#2E5FA8',
  muted:     '#8AAAC4',
  white:     '#FFFFFF',
};

const PAINS = [
  {
    icon: '📱',
    title: 'Customers message. You don\'t see it until it\'s too late.',
    body:  'You\'re on a job, in the kitchen, or serving someone else. By the time you respond, they\'ve already called your competitor.',
  },
  {
    icon: '📋',
    title: 'Quotations take days instead of minutes.',
    body:  'Customers want answers fast. The longer your quote takes, the more likely they are to go elsewhere — even if your price is better.',
  },
  {
    icon: '😓',
    title: 'You\'re doing everything yourself and the admin never ends.',
    body:  'Marketing, follow-ups, invoicing, customer service. You started a business but ended up with a job that works you seven days a week.',
  },
];

const STEPS = [
  {
    num:   '01',
    title: 'We listen first',
    body:  'We start by understanding your business — what\'s frustrating you, what\'s costing you, and what you actually need. No pitch. Just a conversation.',
  },
  {
    num:   '02',
    title: 'We show you the solution',
    body:  'Once we understand your specific problem, we show you exactly how we\'d solve it — and what it means for your business in rands and real results.',
  },
  {
    num:   '03',
    title: 'We build it and stay with you',
    body:  'We set it up, show you how it works, and stay available when you need us. You focus on your business. We handle the rest.',
  },
];

export default function Home() {
  const [chatOpen, setChatOpen] = useState(false);

  const openChat = () => setChatOpen(true);

  return (
    <>
      <Head>
        <title>BornStar Technology — Hammanskraal</title>
        <meta name="description" content="BornStar Technology helps local businesses in Hammanskraal capture every lead, respond instantly, and grow — without adding more to your plate." />
        <meta name="viewport" content="width=device-width, initial-scale=1" />
        <meta property="og:title"       content="BornStar Technology" />
        <meta property="og:description" content="Local businesses in Hammanskraal lose customers every day — not because of bad products, but because nobody answered." />
        <meta property="og:type"        content="website" />
      </Head>

      <div style={{ background: C.navy, minHeight: '100vh', fontFamily: 'Poppins, sans-serif' }}>

        {/* ── NAV ── */}
        <nav style={{
          position: 'sticky', top: 0, zIndex: 40,
          background: 'rgba(10,22,40,0.97)', backdropFilter: 'blur(12px)',
          borderBottom: '1px solid rgba(255,255,255,0.08)',
        }}>
          <div style={{
            maxWidth: 960, margin: '0 auto', padding: '16px 24px',
            display: 'flex', alignItems: 'center', justifyContent: 'space-between',
          }}>
            {/* Logo */}
            <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
              <div style={{
                width: 36, height: 36, borderRadius: 10, background: C.green,
                display: 'flex', alignItems: 'center', justifyContent: 'center',
                fontFamily: 'Montserrat, sans-serif', fontWeight: 900, fontSize: 18, color: C.navy,
              }}>B</div>
              <span style={{ fontFamily: 'Montserrat, sans-serif', fontWeight: 700, fontSize: 17, color: C.white }}>
                BornStar{' '}
                <span style={{ color: C.muted, fontWeight: 400 }}>Technology</span>
              </span>
            </div>

            {/* CTA */}
            <button
              onClick={openChat}
              style={{
                background: C.green, color: C.navy, fontWeight: 700, fontSize: 14,
                padding: '10px 22px', borderRadius: 999, border: 'none', cursor: 'pointer',
                fontFamily: 'Poppins, sans-serif', transition: 'opacity 0.2s',
              }}
              onMouseEnter={(e) => (e.currentTarget.style.opacity = '0.88')}
              onMouseLeave={(e) => (e.currentTarget.style.opacity = '1')}
            >
              Talk to Star
            </button>
          </div>
        </nav>

        {/* ── HERO ── */}
        <section style={{ maxWidth: 960, margin: '0 auto', padding: '80px 24px 96px' }}>

          {/* Badge */}
          <div style={{
            display: 'inline-flex', alignItems: 'center', gap: 8,
            background: 'rgba(245,166,35,0.08)', border: '1px solid rgba(245,166,35,0.25)',
            borderRadius: 999, padding: '6px 16px', marginBottom: 32,
          }}>
            <div style={{ width: 7, height: 7, borderRadius: '50%', background: C.green }} />
            <span style={{ color: C.gold, fontSize: 11, fontWeight: 600, letterSpacing: '1.8px', textTransform: 'uppercase' }}>
              Serving Hammanskraal &amp; Pretoria
            </span>
          </div>

          {/* Headline */}
          <h1 style={{
            fontFamily: 'Montserrat, sans-serif', fontWeight: 900,
            fontSize: 'clamp(32px, 6vw, 58px)', lineHeight: 1.15,
            color: C.white, margin: '0 0 24px', maxWidth: 700,
          }}>
            You're too busy working.{' '}
            <span style={{ color: C.gold }}>Your customers aren't waiting.</span>
          </h1>

          {/* Sub */}
          <p style={{
            color: C.muted, fontSize: 'clamp(15px, 2.2vw, 18px)',
            lineHeight: 1.75, margin: '0 0 40px', maxWidth: 560,
          }}>
            Every missed call, unanswered WhatsApp, and slow quote is a customer that went somewhere else.
            BornStar Technology helps local businesses fix that — without adding more to your plate.
          </p>

          {/* CTAs */}
          <div style={{ display: 'flex', flexWrap: 'wrap', gap: 14 }}>
            <button
              onClick={openChat}
              style={{
                background: C.green, color: C.navy, fontWeight: 700, fontSize: 15,
                padding: '14px 30px', borderRadius: 999, border: 'none', cursor: 'pointer',
                fontFamily: 'Poppins, sans-serif', transition: 'opacity 0.2s',
              }}
              onMouseEnter={(e) => (e.currentTarget.style.opacity = '0.88')}
              onMouseLeave={(e) => (e.currentTarget.style.opacity = '1')}
            >
              Tell me your biggest challenge →
            </button>
            <a
              href="https://wa.me/27781759560?text=Hi%20Nelson%2C%20I%20want%20to%20know%20more%20about%20BornStar%20Technology"
              target="_blank" rel="noopener noreferrer"
              style={{
                color: C.white, fontWeight: 600, fontSize: 15,
                padding: '14px 30px', borderRadius: 999,
                border: '1px solid rgba(255,255,255,0.20)', textDecoration: 'none',
                fontFamily: 'Poppins, sans-serif', transition: 'border-color 0.2s',
                display: 'inline-block',
              }}
              onMouseEnter={(e) => (e.currentTarget.style.borderColor = 'rgba(255,255,255,0.45)')}
              onMouseLeave={(e) => (e.currentTarget.style.borderColor = 'rgba(255,255,255,0.20)')}
            >
              WhatsApp Nelson directly
            </a>
          </div>
        </section>

        {/* ── PAIN POINTS ── */}
        <section style={{
          background: C.navyCard,
          borderTop: '1px solid rgba(255,255,255,0.08)',
          borderBottom: '1px solid rgba(255,255,255,0.08)',
          padding: '80px 24px',
        }}>
          <div style={{ maxWidth: 960, margin: '0 auto' }}>
            <h2 style={{
              fontFamily: 'Montserrat, sans-serif', fontWeight: 900,
              fontSize: 'clamp(24px, 4vw, 36px)', color: C.white,
              textAlign: 'center', margin: '0 0 12px',
            }}>
              Does any of this sound familiar?
            </h2>
            <p style={{ color: C.muted, textAlign: 'center', margin: '0 0 52px', maxWidth: 480, marginLeft: 'auto', marginRight: 'auto' }}>
              These are the problems we hear every week from local business owners in Hammanskraal.
            </p>

            <div style={{
              display: 'grid',
              gridTemplateColumns: 'repeat(auto-fit, minmax(260px, 1fr))',
              gap: 24,
            }}>
              {PAINS.map((item, i) => (
                <div key={i} style={{
                  background: C.navy, borderRadius: 18, padding: '28px 24px',
                  border: '1px solid rgba(255,255,255,0.08)',
                  transition: 'border-color 0.2s',
                }}
                  onMouseEnter={(e) => (e.currentTarget.style.borderColor = 'rgba(245,166,35,0.30)')}
                  onMouseLeave={(e) => (e.currentTarget.style.borderColor = 'rgba(255,255,255,0.08)')}
                >
                  <div style={{ fontSize: 40, marginBottom: 18 }}>{item.icon}</div>
                  <h3 style={{ color: C.white, fontWeight: 600, fontSize: 15, lineHeight: 1.45, margin: '0 0 12px' }}>
                    {item.title}
                  </h3>
                  <p style={{ color: C.muted, fontSize: 13, lineHeight: 1.75, margin: 0 }}>
                    {item.body}
                  </p>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* ── HOW IT WORKS ── */}
        <section style={{ padding: '80px 24px' }}>
          <div style={{ maxWidth: 960, margin: '0 auto' }}>
            <h2 style={{
              fontFamily: 'Montserrat, sans-serif', fontWeight: 900,
              fontSize: 'clamp(24px, 4vw, 36px)', color: C.white,
              textAlign: 'center', margin: '0 0 12px',
            }}>
              Here's how we work with you
            </h2>
            <p style={{ color: C.muted, textAlign: 'center', margin: '0 0 52px', maxWidth: 440, marginLeft: 'auto', marginRight: 'auto' }}>
              We don't sell packages. We solve your specific problem. Here's the process.
            </p>

            <div style={{
              display: 'grid',
              gridTemplateColumns: 'repeat(auto-fit, minmax(240px, 1fr))',
              gap: 40,
            }}>
              {STEPS.map((step, i) => (
                <div key={i} style={{ position: 'relative', paddingTop: 32 }}>
                  {/* Big number behind */}
                  <div style={{
                    fontFamily: 'Montserrat, sans-serif', fontWeight: 900,
                    fontSize: 88, color: 'rgba(245,166,35,0.10)',
                    position: 'absolute', top: -16, left: -8,
                    lineHeight: 1, userSelect: 'none', pointerEvents: 'none',
                  }}>{step.num}</div>
                  <h3 style={{ color: C.white, fontWeight: 600, fontSize: 17, margin: '0 0 12px' }}>
                    {step.title}
                  </h3>
                  <p style={{ color: C.muted, fontSize: 14, lineHeight: 1.75, margin: 0 }}>
                    {step.body}
                  </p>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* ── STAR CTA ── */}
        <section style={{
          background: C.navyCard,
          borderTop: '1px solid rgba(255,255,255,0.08)',
          borderBottom: '1px solid rgba(255,255,255,0.08)',
          padding: '80px 24px',
        }}>
          <div style={{ maxWidth: 600, margin: '0 auto', textAlign: 'center' }}>
            {/* Star avatar */}
            <div style={{
              width: 64, height: 64, borderRadius: 18,
              background: 'rgba(84,242,40,0.10)', border: '1px solid rgba(84,242,40,0.25)',
              display: 'flex', alignItems: 'center', justifyContent: 'center',
              margin: '0 auto 24px',
              fontFamily: 'Montserrat, sans-serif', fontWeight: 900, fontSize: 26, color: C.green,
            }}>S</div>

            <h2 style={{
              fontFamily: 'Montserrat, sans-serif', fontWeight: 900,
              fontSize: 'clamp(22px, 4vw, 32px)', color: C.white, margin: '0 0 16px',
            }}>
              Talk to Star — BornStar's AI consultant
            </h2>
            <p style={{ color: C.muted, lineHeight: 1.75, margin: '0 0 36px', fontSize: 15 }}>
              Star will ask you a few questions about your business and help figure out exactly where you're
              losing time or customers. No pitch. No obligation. Just clarity.
            </p>
            <button
              onClick={openChat}
              style={{
                background: C.green, color: C.navy, fontWeight: 700, fontSize: 15,
                padding: '14px 32px', borderRadius: 999, border: 'none', cursor: 'pointer',
                fontFamily: 'Poppins, sans-serif', transition: 'opacity 0.2s',
              }}
              onMouseEnter={(e) => (e.currentTarget.style.opacity = '0.88')}
              onMouseLeave={(e) => (e.currentTarget.style.opacity = '1')}
            >
              Start the conversation →
            </button>
          </div>
        </section>

        {/* ── FOOTER ── */}
        <footer style={{ padding: '48px 24px 32px' }}>
          <div style={{
            maxWidth: 960, margin: '0 auto',
            display: 'flex', flexWrap: 'wrap', justifyContent: 'space-between',
            alignItems: 'flex-start', gap: 32,
            paddingBottom: 32, borderBottom: '1px solid rgba(255,255,255,0.08)',
          }}>
            {/* Brand */}
            <div>
              <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 8 }}>
                <div style={{
                  width: 28, height: 28, borderRadius: 8, background: C.green,
                  display: 'flex', alignItems: 'center', justifyContent: 'center',
                  fontFamily: 'Montserrat, sans-serif', fontWeight: 900, fontSize: 14, color: C.navy,
                }}>B</div>
                <span style={{ fontFamily: 'Montserrat, sans-serif', fontWeight: 700, fontSize: 15, color: C.white }}>
                  BornStar Technology
                </span>
              </div>
              <p style={{ color: C.muted, fontSize: 13, margin: '0 0 4px' }}>Hammanskraal · Pretoria · South Africa</p>
              <p style={{ color: 'rgba(138,170,196,0.50)', fontSize: 12, margin: 0 }}>VAT No: 9066844300</p>
            </div>

            {/* Contact */}
            <div style={{ textAlign: 'right' }}>
              <p style={{ color: C.white, fontWeight: 600, fontSize: 14, margin: '0 0 4px' }}>Nelson Mhlolo</p>
              <a
                href="https://wa.me/27781759560"
                style={{ color: C.green, fontSize: 14, textDecoration: 'none' }}
              >
                078 175 9560
              </a>
              <p style={{ margin: '6px 0 0' }}>
                <a
                  href="mailto:nelson@zambrotaholdings.co.za"
                  style={{ color: C.muted, fontSize: 12, textDecoration: 'none' }}
                >
                  nelson@zambrotaholdings.co.za
                </a>
              </p>
            </div>
          </div>

          <div style={{ maxWidth: 960, margin: '24px auto 0', textAlign: 'center' }}>
            <p style={{ color: 'rgba(138,170,196,0.45)', fontSize: 12, margin: 0 }}>
              © {new Date().getFullYear()} BornStar Technology (Pty) Ltd · All rights reserved
            </p>
          </div>
        </footer>
      </div>

      <ChatWidget isOpen={chatOpen} setIsOpen={setChatOpen} />
    </>
  );
}
