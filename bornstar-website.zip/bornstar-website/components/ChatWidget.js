import { useState, useRef, useEffect } from 'react';

const C = {
  navy:      '#0A1628',
  navyDark:  '#060E1A',
  navyCard:  '#0F1E35',
  navyLight: '#1A2E4A',
  green:     '#54F228',
  gold:      '#F5A623',
  muted:     '#8AAAC4',
  white:     '#FFFFFF',
};

const OPENING = {
  role: 'assistant',
  content:
    "Hi! I'm Star — BornStar Technology's assistant. I'm not here to sell you anything. I just want to understand your business. What type of business do you run?",
};

export default function ChatWidget({ isOpen, setIsOpen }) {
  const [messages, setMessages] = useState([OPENING]);
  const [input, setInput]       = useState('');
  const [loading, setLoading]   = useState(false);
  const endRef                  = useRef(null);

  useEffect(() => {
    if (isOpen && endRef.current) {
      endRef.current.scrollIntoView({ behavior: 'smooth' });
    }
  }, [messages, isOpen]);

  const send = async () => {
    if (!input.trim() || loading) return;

    const userMsg     = { role: 'user', content: input.trim() };
    const newMessages = [...messages, userMsg];
    setMessages(newMessages);
    setInput('');
    setLoading(true);

    try {
      const res  = await fetch('/api/chat', {
        method:  'POST',
        headers: { 'Content-Type': 'application/json' },
        body:    JSON.stringify({ messages: newMessages }),
      });
      const data = await res.json();
      if (data.message) {
        setMessages((prev) => [...prev, { role: 'assistant', content: data.message }]);
      }
    } catch {
      setMessages((prev) => [
        ...prev,
        { role: 'assistant', content: 'Something went wrong. Please WhatsApp Nelson on 078 175 9560.' },
      ]);
    } finally {
      setLoading(false);
    }
  };

  const onKey = (e) => {
    if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); send(); }
  };

  return (
    <>
      {/* Floating button */}
      <button
        onClick={() => setIsOpen(!isOpen)}
        aria-label="Chat with Star"
        style={{
          position: 'fixed', bottom: 24, right: 24, zIndex: 50,
          width: 56, height: 56, borderRadius: '50%',
          background: C.green, border: 'none', cursor: 'pointer',
          display: 'flex', alignItems: 'center', justifyContent: 'center',
          boxShadow: '0 8px 32px rgba(84,242,40,0.35)',
          transition: 'transform 0.2s',
        }}
        onMouseEnter={(e) => (e.currentTarget.style.transform = 'scale(1.08)')}
        onMouseLeave={(e) => (e.currentTarget.style.transform = 'scale(1)')}
      >
        {isOpen ? (
          <svg width="18" height="18" viewBox="0 0 24 24" fill="none"
            stroke={C.navy} strokeWidth="3" strokeLinecap="round">
            <line x1="18" y1="6" x2="6" y2="18" />
            <line x1="6" y1="6" x2="18" y2="18" />
          </svg>
        ) : (
          <svg width="22" height="22" viewBox="0 0 24 24" fill="none"
            stroke={C.navy} strokeWidth="2.2">
            <path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z" />
          </svg>
        )}
      </button>

      {/* Panel */}
      {isOpen && (
        <div style={{
          position: 'fixed', bottom: 92, right: 16, zIndex: 50,
          width: 'min(360px, calc(100vw - 32px)',
          background: C.navyCard, borderRadius: 20,
          border: '1px solid rgba(255,255,255,0.10)',
          boxShadow: '0 24px 64px rgba(0,0,0,0.5)',
          display: 'flex', flexDirection: 'column', overflow: 'hidden',
        }}>

          {/* Header */}
          <div style={{
            background: C.navyDark, padding: '12px 16px',
            display: 'flex', alignItems: 'center', gap: 10,
            borderBottom: '1px solid rgba(255,255,255,0.08)',
          }}>
            <div style={{
              width: 36, height: 36, borderRadius: '50%',
              background: C.green, flexShrink: 0,
              display: 'flex', alignItems: 'center', justifyContent: 'center',
              fontFamily: 'Montserrat, sans-serif', fontWeight: 900,
              fontSize: 15, color: C.navy,
            }}>S</div>
            <div>
              <p style={{ color: C.white, fontWeight: 600, fontSize: 14, margin: 0 }}>Star</p>
              <p style={{ color: C.muted, fontSize: 11, margin: 0 }}>BornStar Technology · Online</p>
            </div>
            <div style={{
              marginLeft: 'auto', width: 8, height: 8,
              borderRadius: '50%', background: C.green,
              boxShadow: '0 0 6px rgba(84,242,40,0.6)',
            }} />
          </div>

          {/* Messages */}
          <div className="chat-scroll" style={{
            flex: 1, overflowY: 'auto', padding: '14px 14px 8px',
            display: 'flex', flexDirection: 'column', gap: 10,
            maxHeight: 300,
          }}>
            {messages.map((msg, i) => (
              <div key={i} style={{
                display: 'flex',
                justifyContent: msg.role === 'user' ? 'flex-end' : 'flex-start',
              }}>
                <div style={{
                  maxWidth: '82%', padding: '9px 13px', fontSize: 13,
                  lineHeight: 1.55, borderRadius: 16,
                  ...(msg.role === 'user'
                    ? { background: C.green, color: C.navy, fontWeight: 600, borderBottomRightRadius: 4 }
                    : { background: C.navyLight, color: C.white, borderBottomLeftRadius: 4 }),
                }}>
                  {msg.content}
                </div>
              </div>
            ))}

            {loading && (
              <div style={{ display: 'flex', justifyContent: 'flex-start' }}>
                <div style={{
                  background: C.navyLight, borderRadius: 16, borderBottomLeftRadius: 4,
                  padding: '10px 14px', display: 'flex', gap: 5, alignItems: 'center',
                }}>
                  {[0,1,2].map((i) => (
                    <span key={i} className="dot" style={{
                      display: 'block', width: 7, height: 7,
                      borderRadius: '50%', background: C.muted,
                    }} />
                  ))}
                </div>
              </div>
            )}
            <div ref={endRef} />
          </div>

          {/* Input */}
          <div style={{
            padding: '10px 12px',
            borderTop: '1px solid rgba(255,255,255,0.08)',
            display: 'flex', gap: 8, alignItems: 'center',
          }}>
            <input
              type="text"
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={onKey}
              placeholder="Type your message…"
              style={{
                flex: 1, background: C.navyLight, color: C.white, fontSize: 13,
                border: '1px solid rgba(255,255,255,0.10)', borderRadius: 12,
                padding: '9px 13px', outline: 'none',
                fontFamily: 'Poppins, sans-serif',
              }}
              onFocus={(e) => (e.target.style.borderColor = 'rgba(84,242,40,0.4)')}
              onBlur={(e)  => (e.target.style.borderColor = 'rgba(255,255,255,0.10)')}
            />
            <button
              onClick={send}
              disabled={!input.trim() || loading}
              style={{
                width: 38, height: 38, borderRadius: 12, border: 'none',
                background: C.green, color: C.navy, cursor: 'pointer',
                display: 'flex', alignItems: 'center', justifyContent: 'center',
                flexShrink: 0, opacity: (!input.trim() || loading) ? 0.4 : 1,
                transition: 'opacity 0.2s',
              }}
            >
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none"
                stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
                <line x1="22" y1="2" x2="11" y2="13" />
                <polygon points="22 2 15 22 11 13 2 9 22 2" />
              </svg>
            </button>
          </div>

        </div>
      )}
    </>
  );
}
