# BornStar Technology — Website

A professional landing page with an AI agent (Star) built on Next.js, Tailwind CSS, and the Anthropic API.

---

## Local Setup

### 1. Install Node.js (if not installed)
Download from: https://nodejs.org (choose LTS version)

### 2. Install dependencies
```bash
npm install
```

### 3. Set up environment variables
```bash
cp .env.local.example .env.local
```
Open `.env.local` and paste your Anthropic API key.
Get your key at: https://console.anthropic.com

### 4. Run locally
```bash
npm run dev
```
Open http://localhost:3000 to see the site.

---

## Deploy to GitHub + Vercel

### Step 1: Push to GitHub
1. Go to https://github.com and create a new repository called `bornstar-website`
2. Make it **Private**
3. Run these commands in your project folder:

```bash
git init
git add .
git commit -m "Initial BornStar Technology website"
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/bornstar-website.git
git push -u origin main
```

### Step 2: Deploy on Vercel
1. Go to https://vercel.com and sign up with GitHub
2. Click **"Add New Project"**
3. Select your `bornstar-website` repository
4. Click **"Environment Variables"** and add:
   - Key: `ANTHROPIC_API_KEY`
   - Value: your API key
5. Click **Deploy**

Your site will be live at: `bornstar-website.vercel.app`

---

## Free Domain Options

| Option | Cost | How to get it |
|--------|------|---------------|
| `yourname.vercel.app` | **Free forever** | Automatic on Vercel deploy |
| `.tk` domain | **Free** | https://freenom.com (register, select free plan) |
| `.co.za` domain | ~R50–100/year | https://afrihost.com or https://domains.co.za |

**Recommendation:** Start with `bornstartechnology.vercel.app` today (free and immediate). Buy a `.co.za` domain when your first client pays.

### Connecting a custom domain on Vercel
1. Buy your domain
2. In Vercel dashboard → your project → Settings → Domains
3. Add your domain and follow the DNS instructions

---

## Project Structure

```
bornstar-website/
├── pages/
│   ├── index.js          # Homepage
│   ├── _app.js           # App wrapper
│   ├── _document.js      # Font loading
│   └── api/
│       └── chat.js       # AI agent API route (Star)
├── components/
│   └── ChatWidget.js     # Floating chat widget
├── styles/
│   └── globals.css       # Global styles + Tailwind
├── .env.local.example    # Environment variable template
└── README.md
```

---

## Star — The AI Agent

Star uses the SPIN selling framework:
- **S**ituation: Understands their business
- **P**roblem: Surfaces their pain
- **I**mplication: Helps them quantify the cost
- **N**eed-Payoff: Gets them to describe the solution themselves

Star never pitches. She asks questions and collects leads for Nelson to follow up on via WhatsApp.

To update Star's behaviour, edit the `SYSTEM_PROMPT` in `pages/api/chat.js`.

---

Built by BornStar Technology · Hammanskraal, Pretoria · 078 175 9560
