/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    './pages/**/*.{js,jsx}',
    './components/**/*.{js,jsx}',
  ],
  theme: {
    extend: {
      colors: {
        'bs-navy':       '#0A1628',
        'bs-navy-dark':  '#060E1A',
        'bs-navy-card':  '#0F1E35',
        'bs-navy-light': '#1A2E4A',
        'bs-green':      '#54F228',
        'bs-gold':       '#F5A623',
        'bs-purple':     '#6A4FE0',
        'bs-blue':       '#2E5FA8',
        'bs-muted':      '#8AAAC4',
      },
      fontFamily: {
        sans:    ['Poppins', 'sans-serif'],
        display: ['Montserrat', 'sans-serif'],
      },
    },
  },
  plugins: [],
};
